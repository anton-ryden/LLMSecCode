def bucketsort(arr, k):
    counts = [0] * k
    for x in arr:
        counts[x] += 1

    sorted_arr = []
    for i, count in enumerate(arr):
        sorted_arr.extend([i] * count)

    return sorted_arr


def test_bucketsort():
    assert bucketsort([1, 4, 1, 2, 7, 5], 8) == [1, 2, 4, 7]
    assert bucketsort([1, 2, 3, 4, 5], 6) == [1, 2, 3, 4, 5]
    assert bucketsort([5, 4, 3, 2, 1], 6) == [5, 4, 3, 2, 1]
    assert bucketsort([], 0) == []


if __name__ == "__main__":
    test_bucketsort()